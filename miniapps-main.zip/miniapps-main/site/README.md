This is a [Vocs](https://vocs.dev) project bootstrapped with the Vocs CLI.
