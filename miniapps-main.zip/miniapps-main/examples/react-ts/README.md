# React Typescript Example

A basic frame built with React and Typescript that uses Wagmi to connect to a wallet.

```
pnpm install
pnpm run dev
```
