# Vanilla Example

Minimal example demonstrating how a Mini App Host and Mini App interact via postMessage.
