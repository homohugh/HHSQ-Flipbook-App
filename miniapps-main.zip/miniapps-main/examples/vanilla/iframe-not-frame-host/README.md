A Mini App is rendered an iframe by parent that does not server as a Mini App host.

This example is used for debugging.
