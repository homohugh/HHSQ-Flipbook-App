# Security Policy

## Reporting a Vulnerability

Contact [security@merklemanufactory.com](mailto:security@merklemanufactory.com).
