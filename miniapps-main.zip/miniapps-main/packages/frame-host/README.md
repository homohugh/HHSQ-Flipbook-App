# @farcaster/frame-host

Library for hosting Mini Apps

## Installation

```bash
pnpm add @farcaster/frame-host
```

## Documentation

For documentation and guides, visit [miniapps.farcaster.xyz](https://miniapps.farcaster.xyz).


