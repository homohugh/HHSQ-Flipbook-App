# @farcaster/create-mini-app

Get up and running quickly with [Mini Apps](https://miniapps.farcaster.xyz) by using the `@farcaster/create-mini-app` CLI.

## Installation

```bash
npm create @farcaster/mini-app
# or
pnpm create @farcaster/mini-app
# or
yarn create @farcaster/mini-app
```

## Documentation

For documentation and guides, visit [miniapps.farcaster.xyz](https://miniapps.farcaster.xyz/docs/getting-started).
