# @farcaster/tsconfig

## 0.0.4

### Patch Changes

- [#283](https://github.com/farcasterxyz/miniapps/pull/283) [`600c53d`](https://github.com/farcasterxyz/miniapps/commit/600c53dadfee4cc1b94ca1ea3b974d34f0bf22ea) Thanks [@deodad](https://github.com/deodad)! - Bumped @farcaster/quick-auth version.

## 0.0.3

### Patch Changes

- [#281](https://github.com/farcasterxyz/miniapps/pull/281) [`18af402`](https://github.com/farcasterxyz/miniapps/commit/18af402a923d61391e5560d3dc0206edc4e2b493) Thanks [@deodad](https://github.com/deodad)! - Added experimental `quickAuth` SDK action.

## 0.0.2

### Patch Changes

- 27e8fca: add sign in action

## 0.0.1

### Patch Changes

- 444a210: ship cjs build alongside esm
