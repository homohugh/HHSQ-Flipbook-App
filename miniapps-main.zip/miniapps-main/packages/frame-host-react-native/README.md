# @farcaster/frame-host-react-native

Library for hosting Mini Apps in React Native

## Installation

```bash
pnpm add @farcaster/frame-host-react-native
```

## Documentation

For documentation and guides, visit [miniapps.farcaster.xyz](https://miniapps.farcaster.xyz).

