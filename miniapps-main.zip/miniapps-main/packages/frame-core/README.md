# @farcaster/frame-core

Build onchain social apps

## Installation

```bash
pnpm add @farcaster/core
```

## Documentation

For documentation and guides, visit [miniapps.farcaster.xyz](https://miniapps.farcaster.xyz).
